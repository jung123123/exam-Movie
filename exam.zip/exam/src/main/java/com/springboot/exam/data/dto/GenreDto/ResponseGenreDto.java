package com.springboot.exam.data.dto.GenreDto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResponseGenreDto {

    private Long GenreNumber;   //번호

    private String GenreName;   //이름
}
