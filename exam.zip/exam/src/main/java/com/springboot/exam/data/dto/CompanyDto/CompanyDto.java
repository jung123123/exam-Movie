package com.springboot.exam.data.dto.CompanyDto;


import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class CompanyDto {

    private Long CompanyNumber;   //번호

    private String CompanyName;   //이름
}
